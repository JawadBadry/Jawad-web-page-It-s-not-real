import { motion } from "framer-motion";
import { ArrowRight, Mail, Linkedin } from "lucide-react";
import { SiGithub, SiX } from "react-icons/si";

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-40 px-6 bg-foreground text-background">
      <div className="container mx-auto max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-serif text-5xl md:text-7xl font-medium mb-8 leading-tight">
              Let's build <br />
              <span className="text-accent italic">something</span> <br />
              together.
            </h2>
            <div className="w-20 h-1 bg-accent mb-12"></div>
            
            <a 
              href="mailto:hello@example.com" 
              className="inline-flex items-center text-xl hover:text-accent transition-colors duration-300 group"
            >
              <Mail className="mr-4 w-6 h-6 text-muted-foreground group-hover:text-accent transition-colors" />
              hello@example.com
            </a>
            
            <div className="flex gap-6 mt-12">
              <a href="#" className="p-3 bg-background/5 rounded-full hover:bg-accent hover:text-white transition-all duration-300" aria-label="GitHub">
                <SiGithub className="w-5 h-5" />
              </a>
              <a href="#" className="p-3 bg-background/5 rounded-full hover:bg-accent hover:text-white transition-all duration-300" aria-label="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="p-3 bg-background/5 rounded-full hover:bg-accent hover:text-white transition-all duration-300" aria-label="X / Twitter">
                <SiX className="w-5 h-5" />
              </a>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-background/5 p-8 md:p-10 rounded-2xl border border-background/10"
          >
            <h3 className="text-2xl font-serif mb-6">Send a message</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-background/70 mb-2">Name</label>
                <input 
                  type="text" 
                  id="name" 
                  className="w-full bg-background/5 border border-background/10 rounded-lg px-4 py-3 text-background focus:outline-none focus:ring-2 focus:ring-accent transition-shadow"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-background/70 mb-2">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  className="w-full bg-background/5 border border-background/10 rounded-lg px-4 py-3 text-background focus:outline-none focus:ring-2 focus:ring-accent transition-shadow"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-background/70 mb-2">Message</label>
                <textarea 
                  id="message" 
                  rows={4}
                  className="w-full bg-background/5 border border-background/10 rounded-lg px-4 py-3 text-background focus:outline-none focus:ring-2 focus:ring-accent transition-shadow resize-none"
                  placeholder="How can I help you?"
                ></textarea>
              </div>
              <button 
                type="submit"
                className="w-full bg-accent text-white rounded-full py-4 font-medium flex items-center justify-center group hover:bg-accent/90 transition-colors"
              >
                Send Message
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
