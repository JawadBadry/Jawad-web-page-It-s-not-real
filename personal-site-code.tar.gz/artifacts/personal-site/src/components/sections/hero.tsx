import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section id="hero" className="min-h-[100dvh] flex items-center pt-20 pb-16 px-6 relative overflow-hidden">
      {/* Abstract background blobs */}
      <div className="absolute top-1/4 -right-1/4 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-1/4 -left-1/4 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto max-w-5xl z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl"
        >
          <div className="inline-flex items-center rounded-full border border-border/50 bg-background/50 backdrop-blur px-3 py-1 text-sm font-medium text-muted-foreground mb-8">
            <span className="flex h-2 w-2 rounded-full bg-accent mr-2 animate-pulse"></span>
            Available for new opportunities
          </div>
          
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-medium tracking-tight text-foreground leading-[1.1] mb-6">
            Hi, I'm Alex. <br />
            I design digital <span className="text-accent italic">experiences</span>.
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mb-10 font-sans">
            A product designer & frontend engineer obsessed with typography, motion, and building tools that feel like magic.
          </p>
          
          <div className="flex flex-wrap items-center gap-4">
            <Button size="lg" className="rounded-full bg-foreground text-background hover:bg-foreground/90 h-12 px-8 text-base" onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}>
              Let's talk
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full h-12 px-8 text-base border-border/80" onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}>
              View my work
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
