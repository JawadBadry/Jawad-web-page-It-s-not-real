import { motion } from "framer-motion";

export function About() {
  return (
    <section id="about" className="py-24 md:py-32 px-6 bg-muted/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-24"
        >
          <div className="md:col-span-5 flex flex-col justify-start">
            <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">Behind the pixels</h2>
            <div className="w-20 h-1 bg-accent mb-8"></div>
          </div>
          
          <div className="md:col-span-7 space-y-6 text-lg text-muted-foreground font-sans leading-relaxed">
            <p>
              I'm a multidisciplinary designer and engineer based in San Francisco. My journey started in architecture, where I learned how space, light, and material affect human behavior. Today, I apply those same principles to digital interfaces.
            </p>
            <p>
              I believe that great software shouldn't just be functional—it should feel crafted. I obsess over the micro-interactions, the typographic hierarchy, and the exact timing of an easing curve.
            </p>
            <p>
              When I'm not pushing pixels or writing React components, you can find me roasting coffee, curating my vinyl collection, or getting lost in the mountains with a film camera.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
