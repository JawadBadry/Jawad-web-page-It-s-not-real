import { motion } from "framer-motion";

const experiences = [
  {
    role: "Senior Product Designer",
    company: "Acme Corp",
    period: "2021 — Present",
    description: "Leading design for the core platform. Established a new design system used by 40+ engineers. Shipped a complete redesign that increased conversion by 24%."
  },
  {
    role: "Design Engineer",
    company: "Nexus Digital",
    period: "2018 — 2021",
    description: "Bridged the gap between design and engineering. Built high-fidelity prototypes and contributed production code to the React frontend."
  },
  {
    role: "UX Designer",
    company: "Studio Alpha",
    period: "2016 — 2018",
    description: "Worked on client projects ranging from fintech dashboards to e-commerce experiences. Conducted user research and usability testing."
  }
];

export function Experience() {
  return (
    <section id="experience" className="py-24 md:py-32 px-6">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">Experience</h2>
          <div className="w-20 h-1 bg-accent"></div>
        </motion.div>

        <div className="relative border-l border-border/60 ml-4 md:ml-0 pl-8 md:pl-0 md:border-none space-y-16">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
              className="relative md:grid md:grid-cols-12 gap-8"
            >
              {/* Mobile Timeline Dot */}
              <div className="absolute -left-[37px] top-1.5 h-3 w-3 rounded-full bg-accent md:hidden"></div>
              
              <div className="md:col-span-3 mb-2 md:mb-0 text-sm font-medium text-muted-foreground pt-1">
                {exp.period}
              </div>
              
              <div className="md:col-span-9 relative">
                {/* Desktop Timeline Elements */}
                <div className="hidden md:block absolute -left-12 top-2 w-4 h-[1px] bg-border/60"></div>
                <div className="hidden md:block absolute -left-16 top-0 bottom-[-4rem] w-[1px] bg-border/60"></div>
                <div className="hidden md:block absolute -left-[66px] top-1.5 h-2 w-2 rounded-full bg-accent outline outline-4 outline-background"></div>
                
                <h3 className="text-2xl font-serif font-medium text-foreground mb-1">{exp.role}</h3>
                <div className="text-accent font-medium mb-4">{exp.company}</div>
                <p className="text-muted-foreground leading-relaxed">
                  {exp.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
