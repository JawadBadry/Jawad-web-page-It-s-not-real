import { motion } from "framer-motion";

const skills = [
  { category: "Design", items: ["UI/UX Design", "Design Systems", "Prototyping", "Typography", "Interaction Design"] },
  { category: "Engineering", items: ["React / Next.js", "TypeScript", "Tailwind CSS", "Framer Motion", "Creative Coding"] },
  { category: "Tools", items: ["Figma", "VS Code", "Linear", "Spline", "Principle"] }
];

export function Skills() {
  return (
    <section id="skills" className="py-24 md:py-32 px-6">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">My toolkit</h2>
          <div className="w-20 h-1 bg-accent"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {skills.map((skillGroup, index) => (
            <motion.div
              key={skillGroup.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <h3 className="text-xl font-medium mb-6 text-foreground border-b border-border pb-4">{skillGroup.category}</h3>
              <ul className="space-y-4">
                {skillGroup.items.map((item) => (
                  <li key={item} className="flex items-center text-muted-foreground group-hover:text-foreground transition-colors duration-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent/40 mr-3 group-hover:bg-accent transition-colors duration-300"></span>
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
