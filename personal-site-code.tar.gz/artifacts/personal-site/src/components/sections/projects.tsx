import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    title: "Onyx Financial",
    description: "A comprehensive design system and dashboard redesign for a modern wealth management platform.",
    tags: ["Product Design", "React", "Design System"],
    year: "2024",
    link: "#"
  },
  {
    title: "Lumina AI",
    description: "Marketing site and web app for a generative AI startup. Focus on immersive scroll experiences.",
    tags: ["Web Design", "Framer Motion", "Next.js"],
    year: "2023",
    link: "#"
  },
  {
    title: "Studio Tracker",
    description: "An elegant, distraction-free time tracking macOS menubar app designed for freelancers.",
    tags: ["UX Design", "Swift", "Desktop"],
    year: "2023",
    link: "#"
  },
  {
    title: "Curator",
    description: "Personal project: A beautiful minimal interface for organizing architectural references and inspiration.",
    tags: ["React", "Tailwind", "Personal"],
    year: "2022",
    link: "#"
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-24 md:py-32 px-6 bg-muted/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="mb-16 md:mb-24 flex flex-col md:flex-row md:items-end justify-between gap-8"
        >
          <div>
            <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">Selected work</h2>
            <div className="w-20 h-1 bg-accent"></div>
          </div>
          <p className="text-muted-foreground max-w-md">
            A collection of projects spanning product design, creative development, and design systems.
          </p>
        </motion.div>

        <div className="flex flex-col gap-12 md:gap-20">
          {projects.map((project, index) => (
            <motion.a
              key={project.title}
              href={project.link}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="group block relative"
            >
              {/* Project Card */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                {/* Image Placeholder */}
                <div className="lg:col-span-7 aspect-[4/3] w-full bg-background rounded-xl border border-border/50 overflow-hidden relative isolate flex items-center justify-center group-hover:border-border transition-colors duration-500">
                  <div className="absolute inset-0 bg-gradient-to-tr from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <span className="font-serif text-4xl text-muted/30 group-hover:text-muted transition-colors duration-500">{project.title.charAt(0)}</span>
                </div>
                
                {/* Content */}
                <div className="lg:col-span-5 flex flex-col justify-center">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-sm font-medium text-accent">{project.year}</span>
                    <div className="h-[1px] w-8 bg-border"></div>
                  </div>
                  
                  <h3 className="text-3xl font-serif font-medium mb-4 group-hover:text-accent transition-colors duration-300 flex items-center">
                    {project.title}
                    <ArrowUpRight className="ml-2 w-6 h-6 opacity-0 -translate-y-2 translate-x-2 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all duration-300" />
                  </h3>
                  
                  <p className="text-muted-foreground text-lg mb-6 font-sans">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map(tag => (
                      <span key={tag} className="px-3 py-1 text-xs font-medium border border-border rounded-full bg-background/50 text-foreground/70">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
